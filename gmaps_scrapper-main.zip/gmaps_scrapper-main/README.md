Scraper of Google Maps "Popular Times" for business entries
